#include <stdio.h>

int main()
{
    int cont =0;
    for(int i = -10000; i<=10000; i++){
        
        printf("Valor do i: %i\n", i);
        cont++;    
        
    }
    printf("valor de cont: %i\n",cont);

    return 0;
}
