#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

int main() {
    
    srand48(time(NULL)); // não ter repetição e é mais preciso//
    
    int pontos;
    double pi;
    printf("Digite o número de pontos a serem gerados: ");
    scanf("%d", &pontos);
    
    int pontos1= 0;
    for (int i = 0; i < pontos; i++) { //aqui é para disparar os pontos dentro do quadrado//

        double x = drand48 () * 2.0 - 1.0;
        double y = drand48 () * 2.0 - 1.0;
        
        if (x*x + y*y <= 1.0) { //aqui vai dizer quantos cairam dentro do circulo//
            pontos1++;
        }
    }
    
     pi = 4.0 * pontos1 / pontos;
    printf("Estimativa de pi: %f\n",pi);
    
    return 0;
}